For Windows, Microsoft Excel 97 or later is required.
For Mac, Microsoft Excel:Mac 2011 or later is required.

For installation and usage instructions please refer to:
https://github.com/marbl/Krona/wiki/ExcelTemplate

For questions and comments please visit:
https://github.com/marbl/Krona/issues
